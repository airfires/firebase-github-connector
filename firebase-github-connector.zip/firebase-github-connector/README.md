# firebase-github-connector

Pushes to `main` deploy automatically to Firebase Hosting and Firestore rules via GitHub Actions.
Admins/users are separated with the `role` custom claim (see `firestore.rules`).

## One-time setup
1. In Firebase Console > Project settings > Service accounts, generate a private key (JSON).
2. In this repo: Settings > Secrets and variables > Actions
   - Secret `FIREBASE_SERVICE_ACCOUNT`: paste the full JSON.
   - Variable `FIREBASE_PROJECT_ID`: your Firebase project ID.
3. Push to `main`. Check the Actions tab.

Never commit the key file. To add Cloud Functions, add `"functions"` to `firebase.json` and `functions` to the `--only` list in the workflow.
