#!/usr/bin/env bash
# Requires GitHub CLI: gh auth login
set -e
git init -b main
git add .
git commit -m "Initial Firebase deploy setup"
gh repo create firebase-github-connector --private --source=. --push
